sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("hc450.officesupplies.product_application.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);